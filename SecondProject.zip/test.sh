#! /bin/bash
java -version
echo "blah"
echo $SYSTEM_DEFAULTWORKINGDIRECTORY
echo "break"
cd $SYSTEM_DEFAULTWORKINGDIRECTORY
dir